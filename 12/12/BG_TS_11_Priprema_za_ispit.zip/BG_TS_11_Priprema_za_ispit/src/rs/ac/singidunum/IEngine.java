package rs.ac.singidunum;

public interface IEngine {
    double calculateConsumption();
}
