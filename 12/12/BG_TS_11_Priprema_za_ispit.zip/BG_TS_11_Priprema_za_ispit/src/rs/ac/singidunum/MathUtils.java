package rs.ac.singidunum;

public class MathUtils {
    public static int add(int a, int b){
        return a + b;
    }
    // write a parameterized test for this class
}
